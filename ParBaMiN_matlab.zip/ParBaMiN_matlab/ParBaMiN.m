%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ParBaMiN, Copyright 2015-2016 by Fahreddin Sukru Torun
%
% Author: Fahreddin Sukru Torun
% email: fsukrutorun@gmail.com
% date: April 2015
% 
% version: RD_v2
% references: "Parallel Minimum Norm Solution of Sparse Block Diagonal 
%                Column Overlapped Underdetermined Systems", 
%                F. Sukru Torun, Murat Manguoglu, Cevdet Aykanat.
%
% This program needs SPQR library (Timothy A. Davis, SuiteSparse package)
%
% For sample execution see run_sample.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function x = ParBaMiN(A,f,blkptr,colptr,p)        

    [Q,R,P,Q2] = factorize(p,A,blkptr,colptr);

    [x] =  solve(p,f,blkptr,colptr,Q,R,P,Q2);

    % Relative residual
    rel_res = norm(A*x-f)/norm(f)
    xnorm = norm(x)

return;

% --------------------------------------------------------
% Routine for QR factorization
%
function [Q,R,P,Q2] = factorize(p,A,blkptr,colptr)
        
    Q2 = cell(p,1);
    Q = cell(p,1);
    R = cell(p,1);
    P = cell(p,1);
    
    for i=1:p,  
        r=[blkptr(i):blkptr(i+1)-1]'; n1=size(r,1);
        c=[colptr(i,1):colptr(i,2)]'; n2=size(c,1);
        
        Ei=A(r,c);
        
        [mi,ni]=size(Ei);        

        opts.Q='Householder';
        opts.ordering='default';
        opts.permutation = 'matrix';
        opts.econ=0;
        [Q{i},R{i},P{i}] =spqr (Ei',opts);
        
        Q2ind=speye(ni,ni);  
        Q2ind=Q2ind(:,mi+1:ni);
        Q2{i}=spqr_qmult(Q{i},Q2ind,1); 
    end
return;


% --------------------------------------------------------
% Routine for solving
%
function [x] = solve(p,f,blkptr,colptr,Q,R,P,Q2)
          
    Mptr = cumsum([1; 1+colptr(1:p-1,2)-colptr(2:p,1)]);
    Cptr = cumsum(colptr(1:p,2)-colptr(1:p,1)+1 - (blkptr(2:p+1) - blkptr(1:p)));
    m = Mptr(p)-1;
    n = size(f,1);
    M=sparse(m,Cptr(end)); % Initialize reduced M,g
    g=sparse (m,1);
    
    pi = cell(p,1);
    
    for i=1:p,
        r=[blkptr(i):blkptr(i+1)-1]'; n1=size(r,1);
        c=[colptr(i,1):colptr(i,2)]'; n2=size(c,1);
        
        if (i>1), p3=[Mptr(i-1):Mptr(i)-1]'; else p3=[]; end;
        n3=size(p3,1);
        if (i<p), p4=[Mptr(i):Mptr(i+1)-1]'; else p4=[]; end;
        n4=size(p4,1);
        
%         pi{i} = spqr_qmult (Q,(R*P')'\fi,1) ;
        mi = size(R{i},1);
        ni =size(Q{i}.H,1);
        fi=f(r,:);
        rr=(R{i}*P{i}')'\fi;  
        
        zz = zeros(ni,1);
        zz(1:mi,:)=rr;
        pi{i}=spqr_qmult (Q{i},zz,1) ;        
        
        if (i==1), 
            cc = 1: Cptr(i);
            M(p4,cc) = Q2{i}(n2-n4+1:n2,:);
            g(p4,:)=g(p4,:)-pi{i}(n2-n4+1:n2,:);             
        elseif (i<p), 
            cc = Cptr(i-1) + 1 : Cptr(i); % : Mptr(i);
            M(p4,cc)=Q2{i}(n2-n4+1:n2,:);
            M(p3,cc)=-Q2{i}(1:n3,:);
            g(p4)=g(p4)-pi{i}(n2-n4+1:n2);
            g(p3)=g(p3)+pi{i}(1:n3);
        else
            cc = Cptr(i-1) + 1: Cptr(i);
            M(p3,cc)=-Q2{i}(1:n3,:);                 
            g(p3,:)=g(p3,:)+pi{i}(1:n3,:);
        end;
    end; 
    
%   Solving reduced system
    y = spqr_solve(M,g,struct('solution','min2norm'));
    x=zeros(n,1); % Initialize solution 
    
    for i=1:p, % Compute x-blocks 
        r=[blkptr(i):blkptr(i+1)-1]'; n1=size(r,1);
        c=[colptr(i,1):colptr(i,2)]'; n2=size(c,1);
        
        if (i==1), cc = 1: Cptr(i); % y-index
        elseif (i<p), cc = Cptr(i-1) + 1 : Cptr(i);
        else cc=Cptr(i-1)+1: size(M,2);
        end;
         x(c)=pi{i}+ Q2{i} * y(cc);
    end;
return;
