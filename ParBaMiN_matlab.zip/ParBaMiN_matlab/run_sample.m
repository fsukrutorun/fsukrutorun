%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ParBaMiN, Copyright 2015-2016 by Fahreddin Sukru Torun
%
% Author: Fahreddin Sukru Torun
% email: fsukrutorun@gmail.com
% date: April 2015
% 
% version: RD_v2
% references: "Parallel Minimum Norm Solution of Sparse Block Diagonal 
%                Column Overlapped Underdetermined Systems", 
%                F. Sukru Torun, Murat Manguoglu, Cevdet Aykanat.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function run_sample()
    A = mmread('lp_grow22.mtx');
    f = ones(size(A,1),1); 
    
    indfile = fopen('lp_grow22.indices.4');
    blkptr = fscanf(indfile, '%d');  
    blkptr = blkptr +1; 
    colptr = block_nnz( A,4,blkptr );
    
    x = ParBaMiN(A,f,blkptr,colptr,4);
    
return;


function [blknnz] = block_nnz ( A, p, blkptr )
    n = size(A,2);
    blknnz = zeros(p,2); blknnz(1,1)=1; blknnz(p,2)=n;
    for k=1:p,
        p1=[blkptr(k):blkptr(k+1)-1]';
        [r,s] = find(A(p1,:));
        if (k>1), blknnz(k,1)=min(s); end;
        if (k<p), blknnz(k,2)=max(s); end;
    end;
return;
