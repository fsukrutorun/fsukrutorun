/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * ParBaMiN, Copyright 2015-2016 by Fahreddin Sukru Torun
 * 
 * ParBaMiN : Parallel Balance Scheme Algorithm for Minimum Norm 
              solution of parse Block Diagonal Column Overlapped 
              Underdetermined Systems 
 * 
 * Author: Fahreddin Sukru Torun
 * email: fsukrutorun@gmail.com
 * date: August 2015
 * 
 * version: RD_v3
 * 
 * references: "Parallel Minimum Norm Solution of Sparse Block Diagonal 
                Column Overlapped Underdetermined Systems", 
                F. Sukru Torun, Murat Manguoglu, Cevdet Aykanat.
 * 
 * see README.txt for compilation and execution details
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <mpi.h>
#include <sched.h>
#include <omp.h>
//#include <mkl.h>
#include "spqr.hpp"
#include "SuiteSparseQR.hpp"
#include "umfpack.h"
#include "cholmod.h"
#include <getopt.h>
#include <unistd.h>
#include <ios>
#include <iostream>
#include <fstream>
#include <string>
#include <sys/resource.h>
#include <string.h>
#include <mkl_pblas.h>

#define Int Long

int numthreads_SPQR=1,ordering=2;

void readVector(char *fname, Int *A, int sz);
void readMatrixParts(char *finname, int *rowPart);
int Rsolve(Int n, cholmod_sparse *R, double *X, Int nx, cholmod_common *cc);
void blknnz(cholmod_triplet *, cholmod_dense **,int *, int *, MPI_Comm,	cholmod_common *cc);
void printError(char *, int);
void printusage();
void parseinputs(int argc, char *argv[], char *mtxfile, char *rowPartfile,char *frow, char *fcol);
double check_result(cholmod_sparse *GA, cholmod_dense *FinalResult,	cholmod_dense *GlobalF, cholmod_common *cc);

cholmod_dense *construct_M_Sparse(cholmod_sparse *Q2, cholmod_dense *pi, int *rowPart, int *colPart, int **p1, int *n1, int *Cptr, int *Mptr, MPI_Comm comm, cholmod_common *cc, double *);
cholmod_dense *particular_soln_house_dense(cholmod_sparse *A, cholmod_dense *f1, cholmod_dense **Q2, cholmod_sparse **H, cholmod_dense **HTau,Int **HPinv, int *rowPart,int *colPart, int *Mptr, MPI_Comm new_comm, cholmod_common *cc,double *time) ;
cholmod_dense *particular_soln_house_dense2(cholmod_sparse *A, cholmod_dense *f1, cholmod_dense **Q2, cholmod_sparse **H, cholmod_dense **HTau,Int **HPinv, int *rowPart,int *colPart, int *Mptr, MPI_Comm new_comm, cholmod_common *cc,double *time) ;
void gather_soln(cholmod_sparse *H, cholmod_dense *HTau,Int *HPinv, cholmod_dense *pi,	cholmod_dense *FinalResult, cholmod_dense *Ydense, int **p2, int *n2,int *Cptr,	int *rowPart, int *colPart,int *Mptr,MPI_Comm, cholmod_common *cc);
void transfer_soln(cholmod_sparse *H, cholmod_dense *HTau,Int *HPinv, cholmod_dense *pi,cholmod_dense *Ydense, int *Cptr, int *rowPart, int *colPart, int *Mptr ,MPI_Comm,cholmod_common *cc);
cholmod_dense* ParBaMiN(cholmod_sparse *GA, cholmod_dense *Gf, int *rowPart, MPI_Comm comm, double *,cholmod_common *cc);
void balance(char *mtxfile,char *rowPartfile,char *frow,char *fcol);
cholmod_dense *solve_reduced(cholmod_sparse *M_sp, cholmod_dense *g, int Ysz, cholmod_common *cc);

int main(int argc, char **argv) 
{
	char mtxfile[150], rowPartfile[150], rowOrderFile[150], colOrderFile[150];
	
	MPI_Init(&argc, &argv);	
	parseinputs(argc, argv, mtxfile, rowPartfile, rowOrderFile, colOrderFile);
	
	/* Proposed algorithm */
	balance(mtxfile, rowPartfile, rowOrderFile, colOrderFile);

	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Finalize();
	return 0;
}

void balance(char *mtxfile,char *rowPartfile,char *rowOrderFile,char *colOrderFile)
{ 
	cholmod_common Common, *cc;
	cc = &Common;
	cholmod_l_start(cc);
	int mtype,numProcs,myId;
	MPI_Comm_size(MPI_COMM_WORLD, &numProcs);
	MPI_Comm_rank(MPI_COMM_WORLD, &myId);
	cholmod_sparse *GA;
	
	FILE *pf;
	pf = fopen(mtxfile, "r");
	if (!pf){
		printf("Can not open %s mtxfile \n", mtxfile);
		MPI_Finalize();
		exit(0);
	}

	cholmod_sparse *GlobA = (cholmod_sparse *) cholmod_l_read_matrix(pf, 1, &mtype, cc); // input 0= triplet | 1 = unsym sparse
	
	//~ printf("nrow : %lu  ncol: %lu nnz %ld \n",GlobA->nrow,GlobA->ncol,cholmod_l_nnz(GlobA,cc));
	int *rowPart = (int *)calloc(sizeof(int), numProcs+1);
	Int *roworder = (Int *)calloc(GlobA->nrow,sizeof(Int));
	Int *colorder = (Int *)calloc(GlobA->ncol,sizeof(Int));
	readVector(rowOrderFile, roworder, GlobA->nrow);
	readVector(colOrderFile, colorder, GlobA->ncol);

	/*  GA : reordered matrix of GlobA */
	GA = cholmod_l_submatrix(GlobA, roworder, GlobA->nrow, colorder,GlobA->ncol, TRUE, TRUE, cc);	
	/* free memory */	
	cholmod_l_free_sparse(&GlobA,cc);		
	fclose(pf);
	
	printError((char *)"cholmod_l_submatrix", cc->status);
	cholmod_dense *FinalResult;		
	
	// RHS is a vector = 1
	cholmod_dense *GlobalF = cholmod_l_ones(GA->nrow, 1, CHOLMOD_REAL, cc);	
	//cholmod_dense *GlobalF = cholmod_l_zeros(GA->nrow, 1, CHOLMOD_REAL, cc);	

	//cholmod_dense *onesVector = cholmod_l_ones(GA->ncol, 1, CHOLMOD_REAL, cc);	
	//double one [2] = { 1, 0 }, zero [2] = { 0, 0 };
	//cholmod_dense *GlobalF = (cholmod_dense *) cholmod_l_allocate_dense(GA->nrow, 1, GA->nrow, CHOLMOD_REAL, cc);
	//cholmod_l_sdmult(GA, FALSE, one, zero, onesVector, GlobalF, cc);
	
        
	/* Parameters for multithreaded SuiteSparseQR */
	cc->SPQR_nthreads = numthreads_SPQR;
	cc->SPQR_small = 1e6;
	cc->SPQR_grain = numthreads_SPQR*2;
	
	if(numthreads_SPQR == 1)
			cc->SPQR_grain = 1;
			
	/* One MPI process for sparse QR factorization when numProcs =1 */
	if (numProcs == 1) 
	{			
		double walgostart1= MPI_Wtime();			
		FinalResult = SuiteSparseQR_min2norm  <double> (ordering, SPQR_DEFAULT_TOL, GA, GlobalF, cc);
		walgostart1 = MPI_Wtime()- walgostart1;

		double rel_normQR1 = check_result(GA, FinalResult, GlobalF, cc);
		double normX1 = cholmod_l_norm_dense(FinalResult, 2, cc);

		struct rusage r_usage;
		getrusage(RUSAGE_SELF,&r_usage);
		double maxMem = r_usage.ru_maxrss/1000000.0;		

		int globnnz = cholmod_l_nnz(GA,cc);
		int n = GA->nrow;
		int m = GA->ncol;	
		
		printf("\n[Sequential run] %d x %d nnz: %d Total_Time: %-8.5lf rel.res: %e norm_x: %e \n\n", n,m,globnnz,walgostart1, rel_normQR1,normX1);				
		//~ printf("[Sequential run] ordering %d taskst %ld thread %d grain %-1.0lf small %e %d x %d %d QR: %-8.5lf %e normx: %e memory %-5.3lf QRmem %ld UBflop %lf frontal matrices %ld tasks %ld tolerance %e \n",ordering,cc->SPQR_istat[3],cc->SPQR_nthreads, cc->SPQR_grain, cc->SPQR_small, n,m,globnnz,walgostart1, rel_normQR1,normX1,maxMem, cc->memory_usage, cc->SPQR_istat[0],cc->SPQR_istat[2],cc->SPQR_istat[3],cc->SPQR_istat[1]);		

	}
	else /* More than one MPI processes */
	{
		/* For timing */	
		double time[3000];
		
		/* read row indices from file, load into rowPart */
		readMatrixParts(rowPartfile, rowPart);			
		
		/* Parallel minimum norm solution of sparse block diagonal column overlapped underdetermined systems */
		time[0] = MPI_Wtime();
		FinalResult = ParBaMiN(GA,GlobalF,rowPart,MPI_COMM_WORLD,time,cc);		
		time[0] = MPI_Wtime() -time[0];
		/* Parallel Proposed algorithm is finished */

		/* Gathering timing results from MPI Processes */	
		MPI_Barrier(MPI_COMM_WORLD);			
		
		MPI_Gather( &time[24], 1, MPI_DOUBLE, &time[100], 1, MPI_DOUBLE, 0, MPI_COMM_WORLD );
		MPI_Reduce (&time[21],&time[51],1,MPI_DOUBLE,MPI_MAX, 0,MPI_COMM_WORLD);
		 
		struct rusage r_usage;
		getrusage(RUSAGE_SELF,&r_usage);
		double maxMem = r_usage.ru_maxrss/1000000.0;
		double totalMem=0.0;		
		MPI_Reduce (&maxMem,&totalMem,1,MPI_DOUBLE,MPI_SUM, 0,MPI_COMM_WORLD);		
					  
		/* Calculation of relative norm */
		if(myId==0){
			pf = fopen(mtxfile, "r");
			if (!pf){
				printf("Can not open %s mtxfile \n", mtxfile);
				MPI_Finalize();
				exit(0);
			}
			GlobA = (cholmod_sparse *) cholmod_l_read_matrix(pf, 1, &mtype, cc); // input 0= triplet | 1 = unsym sparse	
			GA = cholmod_l_submatrix(GlobA, roworder, GlobA->nrow, colorder,GlobA->ncol, TRUE, TRUE, cc);
			cholmod_l_free_sparse(&GlobA,cc);	
						
			int n = GA->nrow;
			int m = GA->ncol;			
			int globnnz = cholmod_l_nnz(GA,cc);			
			double rel_norm = check_result(GA, FinalResult, GlobalF, cc);
			double normX = cholmod_l_norm_dense(FinalResult, 2, cc);			
			cholmod_l_free_sparse(&GA,cc);
			
			printf("\n[Parallel %d Procs] %d x %d nnz: %d Total_Time: %-5.3lf rel.res: %5.5e norm_x %5.5e \n\n",numProcs, n,m,globnnz,time[0],rel_norm,normX);
			
			//~ printf("[Parallel %d Processes] ntaskst %ld nthreads: %d grain %-1.0lf small %0.1e [%d] %d x %d %d algo %-5.3lf %5.5e normX %5.5e rs %1.0lf x %1.0lf %-1.0lf rst %-5.3lf ",numProcs,  cc->SPQR_istat[3],cc->SPQR_nthreads, cc->SPQR_grain,cc->SPQR_small, numProcs, n,m,globnnz,time[0],rel_norm,normX, time[4],time[5],time[6],time[7]);
            //~ printf("commRS %-5.3lf wRS %-5.3lf d2sp %-5.3lf  pi %-5.3lf comm+RS %-5.3lf transfX %-5.3lf",time[8],time[9],time[10],time[1],time[2],time[3]);
            //~ printf(" transpose %-5.3lf QR %-5.3lf QRmax %-5.3lf Rsolve %-5.3lf qmult %-5.3lf  qmult2 %-5.3lf allpi %-5.3lf myMEM %-5.3lf totalMEM %-5.3lf QR2procs ",time[20],time[21],time[51],time[22],time[23],time[24],time[29], maxMem,totalMem);					
			//~ for(int i=0;i<numProcs;i++){
				//~ printf("%-5.3lf ",time[100+i]);
			//~ }
			//~ printf("\n");
		}
	}
	cholmod_l_free_dense(&FinalResult,cc);	
	cholmod_l_free_dense(&GlobalF,cc);
	free(roworder);
	free(colorder);
	free(rowPart);	
}

cholmod_dense* ParBaMiN(cholmod_sparse *GA, cholmod_dense *Gf, int *rowPart, MPI_Comm comm, double *time, cholmod_common *cc){
	int myId, numProcs;	
	cholmod_dense *pi, *Ydense;
	cholmod_sparse *locA,*Q2;
	cholmod_sparse *H;
	cholmod_dense *HTau;
	Int *HPinv;

	MPI_Comm_rank(comm, &myId);
	MPI_Comm_size(comm, &numProcs);	

	int *colPart = (int *)calloc(sizeof(int), numProcs*2);
	int *Cptr = (int *)calloc(sizeof(int), numProcs);
	int **p2= (int **)malloc(numProcs*sizeof(int *));
	int *n2 = (int *)malloc(numProcs*sizeof(int));
	int *Mptr = (int *)calloc(sizeof(int), numProcs);
	
	cholmod_triplet *T = (cholmod_triplet *) cholmod_l_sparse_to_triplet(GA, cc);
	cholmod_dense *FinalResult = (cholmod_dense *) cholmod_l_zeros(T->ncol, 1, CHOLMOD_REAL,cc);
	
	/* Calculate starting & ending column indices for each bloks */
	blknnz(T, &Gf, colPart, rowPart,comm, cc);
	
	/* locA is a Block Sub-Matrix */
	locA = cholmod_l_triplet_to_sparse(T, (size_t) T->nnz, cc);	
	printError((char *)"cholmod_l_triplet_to_sparse", cc->status);
	
	/* ---- free memory ---------- */
	cholmod_l_free_sparse(&GA,cc);			
	cholmod_l_free_triplet(&T,cc);
	
	/* algorithm starts */
	MPI_Barrier(comm);

	/* apply QR factorization and find the particular soln */

	/* Construct HouseHolder dense Q then extract Q2 with spqr_qmult then solve Reduced System */
	cholmod_dense *Q2_dense;
		
	/* apply QR factorization and find the particular soln */
	time[1]= MPI_Wtime();
	pi = particular_soln_house_dense(locA,Gf, &Q2_dense, &H,&HTau,&HPinv,rowPart,colPart, Mptr, comm, cc,time);
	
	/* For full rank systems, you can use the following, comment above and use this
	pi = particular_soln_house_dense(locA,Gf, &Q2_dense, &H,&HTau,&HPinv,rowPart,colPart, Mptr, comm, cc,time);
	*/ 
	time[1]= MPI_Wtime() - time[1];
	
	/* free memory */
	cholmod_l_free_sparse(&locA,cc);
	
	time[10] =  MPI_Wtime();
	if(Mptr[numProcs-1] != 0)
	{
		Q2 = cholmod_l_dense_to_sparse(Q2_dense, TRUE, cc);		
		/* free memory */
		//cholmod_l_free_dense(&Q2_dense,cc);	
	}
	time[10] =  MPI_Wtime()-time[10];
	
	/* construct M and solve the reduced system */
	/* while constructing M Q2 is sparse */
	time[2] =  MPI_Wtime();
	Ydense = construct_M_Sparse(Q2, pi, rowPart, colPart, p2, n2, Cptr, Mptr, comm,cc, time);
	time[2] =  MPI_Wtime() - time[2];	
	
	/* free memory */
	if(Mptr[numProcs-1]!=0) /* if there is no Reduced System */
	{
		cholmod_l_free_sparse(&Q2,cc);	
	}			

	/*Broadcasting the solution of reduced system y */		
	int ycnt = Ydense->nrow;	
	MPI_Bcast(Ydense->x, ycnt, MPI_DOUBLE, 0, comm);		
				
	if (myId ==0) {
		/* gathering partial x vectors from nodes */
		time[3] = MPI_Wtime();
		gather_soln(H,HTau,HPinv, pi, FinalResult, Ydense, p2, n2, Cptr, rowPart, colPart, Mptr, comm, cc);
		time[3]= MPI_Wtime() -time[3];			
	} 
	else {
		/* sending the partial x's to MASTER node */
		transfer_soln(H,HTau,HPinv, pi, Ydense, Cptr, rowPart, colPart, Mptr, comm, cc);
	}
		
	cholmod_l_free_sparse(&H,cc);	
	cholmod_l_free_dense(&HTau,cc);	
	free(HPinv);	
	free(colPart);
	free(Cptr);
	return FinalResult;
}


cholmod_dense *get_Q2(cholmod_sparse *A, int mc, cholmod_sparse *H, cholmod_dense *HTau,Int *HPinv,cholmod_common *cc){		
		cholmod_dense *Q2_dense;	
		cholmod_dense *I_dense = cholmod_l_zeros(mc, A->ncol, CHOLMOD_REAL, cc);
		double *Tx = (double *)I_dense ->x;
		int diff = (A->ncol-mc)*mc;
		for (int i=0; i<mc; i++) {
			Tx[i + diff + (mc * i)] = 1;
		}
		Q2_dense = SuiteSparseQR_qmult <double>(SPQR_XQ, H, HTau, HPinv, I_dense , cc);
		printError((char *)"SuiteSparseQR_qmult", cc->status);
		return Q2_dense;
}


cholmod_dense *particular_soln_house_dense(cholmod_sparse *A, cholmod_dense *f1, cholmod_dense **Q2_out, cholmod_sparse **H_out, cholmod_dense **HTau_out,Int **HPinv_out, int *rowPart,int *colPart, int *Mptr, MPI_Comm new_comm, cholmod_common *cc, double *time) {
	
	double wAll;
	wAll = MPI_Wtime();
	
	double *Tx;
	int myId,numProcs;

	cholmod_sparse *R;
	cholmod_dense *pi;
	Int *Qfill;
	cholmod_sparse *H;
	cholmod_dense *HTau;
	Int *HPinv;
	int m = A->nrow;

	cholmod_dense *Q2_dense;

	MPI_Comm_size(new_comm, &numProcs);
	MPI_Comm_rank(new_comm, &myId);

	cholmod_sparse *AT;
	time[20]= MPI_Wtime();
	AT =cholmod_l_transpose(A, 1, cc);
	time[20]= MPI_Wtime()-time[20];

	time[21]= MPI_Wtime();
	int tol = SPQR_DEFAULT_TOL;
	//SuiteSparseQR <double> (ordering, tol , m, 2, A, NULL, fs, NULL, &pi, &R, &Qfill, &H, &HPinv, &HTau,cc);
	//SuiteSparseQR <double> (ordering, tol , m, 2, AT, NULL, NULL, NULL, NULL, &R, &Qfill, &H, &HPinv, &HTau,cc);
	SuiteSparseQR <double> (ordering, tol , 0, 0, AT, NULL, NULL, NULL, NULL, &R, &Qfill, &H, &HPinv, &HTau,cc);
	time[21]= MPI_Wtime() - time[21];

	double *fxx= (double *)f1->x;
	cholmod_dense *fs = cholmod_l_zeros( A->ncol,1, CHOLMOD_REAL, cc);
	double *fsx= (double *)fs->x;
	for(int i=0;i<m;i++) 
	{
		 fsx[i] = fxx[Qfill[i]];
	}

	/* free memory */
	cholmod_l_free_sparse(&AT,cc);
	free(Qfill);	

	double *fval = (double *) fs->x;

	time[22] = MPI_Wtime();
	Rsolve(A->nrow, R, fval, 1, cc) ;
	time[22]= MPI_Wtime() - time[22];
	

	/* free memory */
	cholmod_l_free_sparse(&R,cc);

	for (size_t i =A->nrow; i<A->ncol; i++)
		fval[i]=0;
		
	time[23]=MPI_Wtime();
	pi = SuiteSparseQR_qmult <double>(SPQR_QX, H, HTau, HPinv, fs, cc);
	printError((char *)"PI 1", cc->status); fflush(0);
	time[23]=MPI_Wtime() - time[23];
	
	time[25] = MPI_Wtime();
	int i;
	Mptr[1] =0;
	for (i=1; i<numProcs; i++) {
		Mptr[i]= Mptr[i-1] + colPart[i*2-1]-colPart[i*2]+1;
	}

	//~ int n1 = rowPart[myId+1]-rowPart[myId];
	//~ int n2 = colPart[2*(myId+1)-1] - colPart[2*(myId)] +1;
	time[25] = MPI_Wtime()-time[25];
		
	//printf("\nReduced System size %d",Mptr[numProcs-1]);

	if(Mptr[numProcs-1] != 0)
	{
		if(myId==0){		
				
			int mc = Mptr[1]-Mptr[0];	
			time[24] = MPI_Wtime();
			Q2_dense = get_Q2(A,mc, H, HTau, HPinv,cc);				
			time[24] = MPI_Wtime()-time[24];
			printError((char *)"SuiteSparseQR_qmult 21", cc->status); fflush(0);
		}
		else if(myId<numProcs-1)
		{
			int mc1 = Mptr[myId+1]-Mptr[myId];			
			int mc2 = Mptr[myId]-Mptr[myId-1];
			
			int sz = mc1+mc2;
			cholmod_dense *I_dense3 = cholmod_l_zeros(sz, A->ncol, CHOLMOD_REAL, cc);
			Tx = (double *)I_dense3 ->x;
			for (int i=0; i<mc2; i++) {
				Tx[i + ((sz) * i)] = -1;
			}
			
			int diff = (A->ncol-mc1)*sz+mc2;
			for (int i=0; i<mc1; i++) {
				Tx[i + diff + (sz * i)] = 1;
			}
			
			time[24]=MPI_Wtime();
			Q2_dense = SuiteSparseQR_qmult <double>(SPQR_XQ, H, HTau, HPinv, I_dense3 , cc);
			time[24]= MPI_Wtime() - time[24];
			printError((char *)"SuiteSparseQR_qmult 22", cc->status);	fflush(0);
			
			/* free memory */
			cholmod_l_free_dense(&I_dense3,cc);
			
			//~ printf("%d Q2_1 %lu %lu Q2_1 %lu %lu \n",myId,Q2_1_dense->nrow,Q2_1_dense->ncol,Q2_2_dense->nrow,Q2_2_dense->ncol);fflush(0);			
		}
		else{
			int mc = Mptr[myId]-Mptr[myId-1];		
			
			cholmod_dense *I_dense = cholmod_l_zeros(mc, A->ncol, CHOLMOD_REAL, cc);
			Tx = (double *)I_dense ->x;
			for (int i=0; i<mc; i++) {
				Tx[i + (mc * i)] = -1;
			}
			
			time[24]=MPI_Wtime();
			Q2_dense = SuiteSparseQR_qmult <double>(SPQR_XQ, H, HTau, HPinv, I_dense , cc);
			time[24]= MPI_Wtime() - time[24];	
			printError((char *)"SuiteSparseQR_qmult 23", cc->status);	fflush(0);
						 
			/* free memory */
			cholmod_l_free_dense(&I_dense,cc);
		}
	}

	//~ double ws2d=MPI_Wtime();   
	//~ *Q2_sparse = cholmod_l_dense_to_sparse(Q2_dense,TRUE,cc);
	//~ ws2d=MPI_Wtime() -ws2d;  
	
	wAll = MPI_Wtime()-wAll;
	time[29]=wAll;
	(*Q2_out) = Q2_dense;
	(*H_out) = H;
	(*HTau_out) = HTau;
	(*HPinv_out) = HPinv;
	return pi;
}


cholmod_dense *particular_soln_house_dense2(cholmod_sparse *A, cholmod_dense *f1, cholmod_dense **Q2_out, cholmod_sparse **H_out, cholmod_dense **HTau_out,Int **HPinv_out, int *rowPart,int *colPart, int *Mptr, MPI_Comm new_comm, cholmod_common *cc, double *time) {
	
	double wAll;
	wAll = MPI_Wtime();
	
	double *Tx;
	int myId,numProcs;

	cholmod_sparse *R;
	cholmod_dense *pi;
	Int *Qfill;
	cholmod_sparse *H;
	cholmod_dense *HTau;
	Int *HPinv;
	int m = A->nrow;
	

	cholmod_dense *Q2_dense;

	MPI_Comm_size(new_comm, &numProcs);
	MPI_Comm_rank(new_comm, &myId);

	cholmod_sparse *AT;
	time[20]= MPI_Wtime();
	AT =cholmod_l_transpose(A, 1, cc);
	time[20]= MPI_Wtime()-time[20];
		
	time[21]= MPI_Wtime();	
	// Sparse QR factorization with pivoting 
	SuiteSparseQR <double> (ordering, SPQR_DEFAULT_TOL, m, 2, AT, NULL, NULL, NULL, NULL, &R, &Qfill, &H, &HPinv, &HTau,cc);
	time[21]= MPI_Wtime() - time[21];
	
	double *fxx= (double *)f1->x;
	cholmod_dense *fs = cholmod_l_zeros( A->nrow,1, CHOLMOD_REAL, cc);
	double *fsx= (double *)fs->x;
		
	for(int i=0;i<m;i++) /* Permutation of f_i */
	{
		 fsx[i] = fxx[Qfill[i]];
	}
		
	/* free memory */
	cholmod_l_free_sparse(&AT,cc);	
	free(Qfill);
			
	time[22] = MPI_Wtime();

	cholmod_sparse *Rsp = cholmod_l_transpose(R, 1, cc);
	cholmod_dense *fsR = cholmod_l_zeros( A->nrow,1, CHOLMOD_REAL, cc);
	fsR  = SuiteSparseQR_min2norm <double> (7, SPQR_DEFAULT_TOL, Rsp, fs, cc);	

	time[22]= MPI_Wtime() - time[22];


	/* free memory */
	cholmod_l_free_sparse(&R,cc);
	cholmod_l_free_sparse(&Rsp,cc);	
	
	double *fval = (double *) fsR->x;	
	cholmod_dense *xfs = cholmod_l_zeros( A->ncol,1, CHOLMOD_REAL, cc);
	double *xfval = (double *) xfs->x;	
	for (size_t i =0; i< A->nrow; i++)
		xfval[i] = fval[i];
		
	time[23]=MPI_Wtime();
	pi = SuiteSparseQR_qmult <double>(SPQR_QX, H, HTau, HPinv, xfs, cc);  // particular soln
	//pi = SuiteSparseQR_qmult <double>(SPQR_QX, H, HTau, HPinv, fs, cc);  // particular soln
	time[23]=MPI_Wtime() - time[23];
		
	int i;
	Mptr[1] =0;
	for (i=1; i<numProcs; i++) {
		Mptr[i]= Mptr[i-1] + colPart[i*2-1]-colPart[i*2]+1;
	}
	
	if(Mptr[numProcs-1] != 0) // if there is Reduced System
	{
		if(myId==0){		
				
			int mc = Mptr[1]-Mptr[0];	
			time[24] = MPI_Wtime();
			Q2_dense = get_Q2(A,mc, H, HTau, HPinv,cc);				
			time[24] = MPI_Wtime()-time[24];
			printError((char *)"SuiteSparseQR_qmult ", cc->status);	
		}
		else if(myId<numProcs-1)
		{
			int mc1 = Mptr[myId+1]-Mptr[myId];			
			int mc2 = Mptr[myId]-Mptr[myId-1];
			
			int sz = mc1+mc2;
			cholmod_dense *I_dense3 = cholmod_l_zeros(sz, A->ncol, CHOLMOD_REAL, cc);
			Tx = (double *)I_dense3 ->x;
			for (int i=0; i<mc2; i++) {
				Tx[i + ((sz) * i)] = -1;
			}
			
			int diff = (A->ncol-mc1)*sz+mc2;
			for (int i=0; i<mc1; i++) {
				Tx[i + diff + (sz * i)] = 1;
			}
			
			time[24]=MPI_Wtime();
			Q2_dense = SuiteSparseQR_qmult <double>(SPQR_XQ, H, HTau, HPinv, I_dense3 , cc);
			time[24]= MPI_Wtime() - time[24];
			printError((char *)"SuiteSparseQR_qmult ", cc->status);	
			
			/* free memory */
			cholmod_l_free_dense(&I_dense3,cc);
			
			//~ printf("%d Q2_1 %lu %lu Q2_1 %lu %lu \n",myId,Q2_1_dense->nrow,Q2_1_dense->ncol,Q2_2_dense->nrow,Q2_2_dense->ncol);fflush(0);
			
		}
		else{
			int mc = Mptr[myId]-Mptr[myId-1];		
			
			cholmod_dense *I_dense = cholmod_l_zeros(mc, A->ncol, CHOLMOD_REAL, cc);
			Tx = (double *)I_dense ->x;
			for (int i=0; i<mc; i++) {
				Tx[i + (mc * i)] = -1;
			}
			
			time[24]=MPI_Wtime();
			Q2_dense = SuiteSparseQR_qmult <double>(SPQR_XQ, H, HTau, HPinv, I_dense , cc);
			time[24]= MPI_Wtime() - time[24];	
			printError((char *)"SuiteSparseQR_qmult ", cc->status);	
						
			/* free memory */
			cholmod_l_free_dense(&I_dense,cc);
		}
	}

	wAll = MPI_Wtime()-wAll;
	time[29]=wAll;
	
	(*Q2_out) = Q2_dense;
	(*H_out) = H;
	(*HTau_out) = HTau;
	(*HPinv_out) = HPinv;
	return pi;
}

cholmod_dense *construct_M_Sparse(cholmod_sparse *Q2, cholmod_dense *pi, int *rowPart, int *colPart, int **p2, int *n2, int *Cptr, int *Mptr, MPI_Comm comm, cholmod_common *cc, double *time) {
	int numProcs, myId, i, j;
	int **p1, **p3, **p4,**p5;
	int *n1, *n3, *n4;
	double wCommRS2, wCommRS1, wRS1, wRS2;

	MPI_Status status;
	MPI_Comm_size(comm, &numProcs);
	MPI_Comm_rank(comm, &myId);	
	MPI_Request *recvReqs = (MPI_Request *) malloc(sizeof(MPI_Request)*(numProcs));

	int *nzmax = (int *) malloc(sizeof(int)*numProcs);	
	cholmod_triplet *M_tr;
	cholmod_dense *g, *Ydense;

	for (i=0; i<numProcs; i++) {
		if (i != 0)
			Cptr[i]= 1+Cptr[i-1] + colPart[(i+1)*2-1] - colPart[(i)*2] -(rowPart[i+1] - rowPart[i]);
		else
			Cptr[i] = colPart[(i+1)*2-1]-colPart[(i)*2] - (rowPart[i+1]-rowPart[i]);
	}
		
	time[4]= Mptr[numProcs-1];
	time[5]= Cptr[numProcs-1]+1;	

	Ydense = (cholmod_dense *) cholmod_l_zeros((Cptr[numProcs-1]+1), 1,	CHOLMOD_REAL, cc);
	
	wCommRS1= MPI_Wtime();
	
	if(Mptr[numProcs-1] != 0) /* if Reduced System exists */
	{
		if (myId == 0) 
		{		
			if(numProcs!=2){
				int divider = (Mptr[numProcs-1] / (numProcs/4));
				int MaxtripletSize = divider *(Cptr[numProcs-1]+1);					
				M_tr = (cholmod_triplet *)cholmod_l_allocate_triplet(Mptr[numProcs-1], Cptr[numProcs-1]+1,MaxtripletSize, 0,	CHOLMOD_REAL, cc);
				printError((char *)"cholmod_l_allocate_triplet M_tr", cc->status);
			}
			else
			{
				M_tr = (cholmod_triplet *)cholmod_l_allocate_triplet(Mptr[numProcs-1], Cptr[numProcs-1]+1,Mptr[numProcs-1] * (Cptr[numProcs-1]+1), 0,	CHOLMOD_REAL, cc);
			}
			g= (cholmod_dense *) cholmod_l_zeros(Mptr[numProcs-1], 1,	CHOLMOD_REAL, cc);
			
			for (i=1; i<numProcs; i++) {
				/* receiving the second part of Q2 */
				MPI_Irecv(&nzmax[i], 1, MPI_INT, i, 801, comm,&recvReqs[i-1]);			
			}
			p1= (int **)malloc(numProcs*sizeof(int *));
			p3= (int **)malloc(numProcs*sizeof(int *));
			p4= (int **)malloc(numProcs*sizeof(int *));
			p5= (int **)malloc(numProcs*sizeof(int *));
			
			n1 = (int *)malloc(numProcs*sizeof(int));
			n3 = (int *)malloc(numProcs*sizeof(int));
			n4 = (int *)malloc(numProcs*sizeof(int));

			Int *Mj = (Int *)M_tr->j;
			Int *Mi = (Int *)M_tr->i;
			double *Mx = (double *)M_tr->x;
			
			for (i=0; i<numProcs; i++) {
				// p1,p2,p3,p4 are auxillary arrays for M and Q2 //
				// n1,n2,n3,n4 are # elts in each array //
				p1[i] = (int *)calloc(rowPart[i+1]-rowPart[i], sizeof(int));
				for (j=0; j<rowPart[i+1]-rowPart[i]; j++)
					p1[i][j]=j+rowPart[i];
				n1[i] = rowPart[i+1]-rowPart[i];
				p2[i] = (int *)calloc(colPart[2*(i+1)-1] - colPart[2*(i)] +1, sizeof(int));
				for (j=0; j<colPart[2*(i+1)-1] - colPart[2*(i)] +1; j++)
					p2[i][j]=j+colPart[2*(i)];
				n2[i] = colPart[2*(i+1)-1] - colPart[2*(i)] +1;

				if (i>0) {
					p3[i] = (int *)calloc(Mptr[i]-Mptr[i-1], sizeof(int));
					for (j=0; j<Mptr[i]-Mptr[i-1]; j++){
						p3[i][j]=j + Mptr[i-1];
					}
					n3[i] = Mptr[i]-Mptr[i-1];
				}
				if (i<numProcs-1) {
					p4[i] = (int *)calloc(Mptr[i+1]-Mptr[i], sizeof(int));
					for (j=0; j<Mptr[i+1]-Mptr[i]; j++)
						p4[i][j]=j + Mptr[i];
					n4[i] = Mptr[i+1]-Mptr[i];
				}
				if(i>0 && i<numProcs-1){
					p5[i] = (int *)calloc(n3[i]+n4[i], sizeof(int));
					int d = n3[i];
					for(j=0;j<d;j++)
						p5[i][j] = p3[i][j];				
					for(j=0;j<n4[i];j++)	
						p5[i][d+j] = p4[i][j];							
				}
				if(i==0)
				{
					int ki;
					double *Ax = (double *)Q2->x;
					Int *Ap = (Int *) Q2->p;
					Int *Ai = (Int *) Q2->i;					
									
					int kc = n2[i]-n1[i];
					int nnz = (int) M_tr->nnz;
					for (int k=0; k<kc; k++) {
						for (int l=Ap[n1[i]+k]; l<Ap[n1[i]+k+1]; l++) {
							int li = Ai[l];		
							Mi[nnz] = (Int) p4[i][li];
							Mj[nnz] = k;
							Mx[nnz++] = Ax[l];
						}
					}
					M_tr->nnz=nnz;
					ki= n2[i]-n4[i];
					double *pix = (double *)pi->x;
					double *gx = (double *) g->x;				
					for (int k=0; k<n4[i]; k++) {
						gx[k]= gx[k] - pix[ki +k];
					}
				}			
			}
			int recvnum = numProcs-1;
			int recved = 0;
			int recvInd = -1000;
			
			while (recved < recvnum) {
				MPI_Status sss;
				MPI_Waitany(recvnum, recvReqs, &recvInd, &sss);

				if (recvInd != MPI_UNDEFINED) {
					recved ++;
					recvReqs[recvInd] = MPI_REQUEST_NULL;
					int i = sss.MPI_SOURCE;
					
					if (i<numProcs-1) {			
						int nzmax1=nzmax[i];
						int ndiff = n2[i]-n1[i]+1;
						double *recved_Ax1 = (double *)calloc(nzmax1 +n3[i]+ n4[i], sizeof(double));
						double *recved_pix1 = (double *)calloc(n3[i],	sizeof(double));
						double *recved_pix2 = (double *)calloc(n4[i], sizeof(double));

						Int *recved_Ai1 = (Int *)calloc(nzmax1 + ndiff,sizeof(Int));
						Int *recved_Ap1 = (Int *)calloc(ndiff,sizeof(Int));				
						
			
						MPI_Recv(recved_Ax1, nzmax1 + n3[i] + n4[i], MPI_DOUBLE,i, 902, comm, &status);
						MPI_Recv(recved_Ai1, nzmax1 + ndiff, MPI_LONG, i, 903, comm, &status);
						
						memcpy(recved_pix1, &recved_Ax1[nzmax1], n3[i]	* sizeof(double));
						memcpy(recved_pix2, &recved_Ax1[nzmax1 + n3[i]], n4[i]* sizeof(double));
						memcpy(recved_Ap1, &recved_Ai1[nzmax1], (ndiff)* sizeof(Int));
						
						int kc = n2[i]-n1[i];
						int first = recved_Ap1[0];		
							
						int nnz = (int) M_tr->nnz; 							
								
						for (int k=0; k<kc; k++) {	
							for (int l=0; l<recved_Ap1[k+1]-recved_Ap1[k]; l++) 
							{
								int li = recved_Ap1[k]-first +l;
								Mi[nnz] = p5[i][recved_Ai1[li]];
								Mj[nnz] = k+Cptr[i-1]+1;
								Mx[nnz++] = recved_Ax1[li];				
							}
						}
						
						M_tr->nnz = nnz;
						
						double *gx = (double *) g->x;				
						for (int k=0; k<n3[i]; k++) {
							gx[p3[i][k]]= gx[p3[i][k]] + recved_pix1[k];					
						}
									
						for (int k=0; k<n4[i]; k++) {
							gx[p4[i][k]]= gx[p4[i][k]] - recved_pix2[k];					
						}
						
						/* free memory */
						free(recved_pix1);
						free(recved_pix2);
										
					} 
					else {						
						int nzmax1 = nzmax[i];						
						double *recved_Ax = (double *)calloc(nzmax1 + n3[i],sizeof(double));
						double *recved_pix = (double *)calloc(n3[i], sizeof(double));
						Int *recved_Ai = (Int *)calloc(nzmax1 + n2[i]-n1[i]+1,sizeof(Int));
						Int *recved_Ap = (Int *)calloc(n2[i]-n1[i]+1,sizeof(Int));

						MPI_Recv(recved_Ax, nzmax1+n3[i], MPI_DOUBLE, i, 902,comm, &status);
						MPI_Recv(recved_Ai, nzmax1 + n2[i]-n1[i]+1, MPI_LONG, i, 903,	comm, &status);

						memcpy(recved_Ap, &recved_Ai[nzmax1], (n2[i]-n1[i]+1)*sizeof(Int));
						memcpy(recved_pix, &recved_Ax[nzmax1], n3[i]*sizeof(double));
						
						int kc = n2[i]-n1[i];
						int first = recved_Ap[0];
						int nnz = (int) M_tr->nnz;					
						for (int k=0; k<kc; k++) {
							int len = recved_Ap[k+1]-recved_Ap[k];					
							for (int l=0; l<len; l++) {
								int li = recved_Ap[k]-first +l;
								Mi[nnz] = (Int) p3[i][recved_Ai[li]];
								Mj[nnz] = k+Cptr[i-1]+1;
								Mx[nnz++] = recved_Ax[li];
							}
						}	
						M_tr->nnz = nnz;
						
						double *gx = (double *) g->x;				
						for (int k=0; k<n3[i]; k++) {
							gx[p3[i][k]]= gx[p3[i][k]] + recved_pix[k];					
						}	
					}
				}
			}
		} else if (myId < numProcs-1) {
			/* sending the second part of Q2 */			
			int n4 = Mptr[myId+1] - Mptr[myId];
			int n3 = Mptr[myId] - Mptr[myId-1];
			int n2 = colPart[2*(myId)+1] - colPart[2*myId]+1;
			int n1 = rowPart[myId+1]-rowPart[myId];
			double *Qx = (double *)Q2->x;
			Int *Qi = (Int *)Q2->i;
			Int *Qp = (Int *)Q2->p;			
			double *pix = (double *)pi->x;		
			
			int sz = Qp[Q2->ncol]-Qp[n1];
			MPI_Send(&sz, 1, MPI_INT, 0, 801, comm);		
			
			int start2 = n2-n4;			
			int ndiff = n2-n1+1;		
			double *sendbufD1 = (double *)calloc(sizeof(double), (sz + n4 + n3));
			Int *sendbufI1 = (Int *)calloc(sizeof(Int),(sz + ndiff));
			
			int diff1 =Qp[n1];		
			
			memcpy(sendbufD1, &Qx[diff1], sz*sizeof(double));			
			memcpy( &sendbufD1[sz], pix, n3*sizeof(double));
			memcpy( &sendbufD1[sz+ n3], &pix[start2], n4*sizeof(double));		
			MPI_Send(sendbufD1, sz + n4 +n3, MPI_DOUBLE, 0, 902, comm);		
		
			memcpy(sendbufI1, &Qi[diff1], sz*sizeof(Int));	
			memcpy( &sendbufI1[sz], &Qp[n1], (ndiff)*sizeof(Int));
			MPI_Send(sendbufI1, sz + ndiff , MPI_LONG, 0, 903, comm);	
				
		} else {
			int n3 = Mptr[myId] - Mptr[myId-1];
			double *Qx = (double *)Q2->x;
			Int *Qi = (Int *)Q2->i;
			Int *Qp = (Int *)Q2->p;		
			int n1 = rowPart[myId+1]-rowPart[myId];
			int n2 = colPart[2*(myId)+1] - colPart[2*myId]+1;		
			int sz =Qp[Q2->ncol]-Qp[n1];
			
			MPI_Send(&sz, 1, MPI_INT, 0, 801, comm);
			double *pix = (double *)pi->x;
			double *sendbufD = (double *)malloc( (sz + n3) * sizeof(double));
			Int *sendbufI = (Int *)malloc( ( sz + n2-n1+1) * sizeof(Int));
			
			int diff =Qp[n1];
			memcpy(sendbufD, &Qx[diff], sz*sizeof(double));
			memcpy( &sendbufD[sz], pix, n3*sizeof(double));		
			MPI_Send(sendbufD, sz + n3, MPI_DOUBLE, 0, 902, comm);
			
			memcpy(sendbufI, &Qi[diff], sz*sizeof(Int));
			memcpy( &sendbufI[sz], &Qp[n1], (n2-n1+1)*sizeof(Int));
			MPI_Send(sendbufI, sz + n2-n1+1, MPI_LONG, 0, 903, comm);
		}	
	
		wCommRS2= MPI_Wtime();
		wRS1 = MPI_Wtime();
		
		if (myId ==0) 
		{	
			cholmod_l_reallocate_triplet(M_tr->nnz, M_tr, cc);
			cholmod_sparse *M_sp = cholmod_l_triplet_to_sparse(M_tr, M_tr->nzmax,cc);
			
			/* free memory */
			cholmod_l_free_triplet(&M_tr,cc);	
			//cholmod_l_drop(1e-6,M_sp,cc);
		
			// solve the reduced system My = hat{p}
			double rst = MPI_Wtime();
			Ydense = solve_reduced (M_sp, g,(Cptr[numProcs-1]+1), cc);			
			rst = MPI_Wtime() - rst;
			time[6] = cholmod_l_nnz(M_sp,cc);
			time[7] = rst;
		        
			// double rel_normRS1 = check_result(M_sp, Ydense, g, cc);
			// printf("red sys solv time %-5.3lf nnz %-ld ntasks %ld nthreads %d \n",rst,cholmod_l_nnz(M_sp,cc),cc->SPQR_istat[3],cc->SPQR_nthreads);//fflush(0);
			// double normY = cholmod_l_norm_dense(Ydense, 2, cc);	
			// printf("\n Reduced System solved with norm(y) : %e relresnorm : %e \n",normY,rel_normRS1);		
			
			wRS2 = MPI_Wtime();
			time[8] = wCommRS2 - wCommRS1;
			time[9] = wRS2 - wRS1;
			
			/* free memory */	
			cholmod_l_free_sparse(&M_sp,cc);		
		}
	}
	
	return Ydense;
}


/* SuiteSparseQR min2norm solution for reduced system*/
cholmod_dense *solve_reduced(cholmod_sparse *M_sp,cholmod_dense *g, int Ysz, cholmod_common *cc)
{
	cholmod_dense *Ydense = (cholmod_dense *) cholmod_l_zeros(Ysz, 1,	CHOLMOD_REAL, cc);
	int RSordering = 6; 
	//~ cc->SPQR_nthreads = 1;
	Ydense = SuiteSparseQR_min2norm <double> (RSordering, SPQR_DEFAULT_TOL, M_sp, g, cc);
	//~ cc->SPQR_nthreads = numthreads_SPQR;	
	return Ydense;		
}

void gather_soln(cholmod_sparse *H, cholmod_dense *HTau,Int *HPinv, cholmod_dense *pi,	cholmod_dense *FinalResult, cholmod_dense *Ydense, int **p2, int *n2,int *Cptr, int *rowPart, int *colPart, int *Mptr, MPI_Comm new_comm, cholmod_common *cc) {
	
	MPI_Status status;
	int numProcs, i,j ;

	int nc = Cptr[0]+1;	
	MPI_Comm_size(new_comm, &numProcs);


	double *Yx = (double *)Ydense->x;		
	int pc = pi->nrow;
	cholmod_dense *yt = (cholmod_dense *) cholmod_l_zeros(pc, 1, CHOLMOD_REAL,cc);
	double *ytx = (double *)yt->x;
	
	if(Mptr[numProcs-1] != 0)
	{
		int rm = pc-nc;	
		for(int z =0;z< nc;z++)
		{
			ytx[rm + z]=Yx[z];			
		}
	}				
	
	cholmod_dense *C = SuiteSparseQR_qmult <double>(SPQR_QX, H, HTau, HPinv, yt, cc);
	double *Xx = (double *)C->x ;
	double *pix = (double *)pi->x ;	

	double *Finx = (double *) FinalResult->x;
		
	/* updating x vector */
	for (i =0; i<pc; i++) {		
		Xx[i] = Xx[i] + pix[i];
		Finx[i]= Xx[i];		
	}	
	
	if(Mptr[numProcs-1] != 0) /* if Reduced system exists */
	{
		/* gathering partial x vectors from nodes */
		for (i=1; i<numProcs; i++){
			MPI_Recv(&Finx[p2[i][0]], n2[i], MPI_DOUBLE, i, 906, new_comm,&status);
		}
	}
	else /* if Reduced system does not exists */
	{
		for (i=1; i<numProcs; i++){
			p2[i] = (int *)calloc(colPart[2*(i+1)-1] - colPart[2*(i)] +1, sizeof(int));
			for (j=0; j<colPart[2*(i+1)-1] - colPart[2*(i)] +1; j++)
				p2[i][j]=j+colPart[2*(i)];
			n2[i] = colPart[2*(i+1)-1] - colPart[2*(i)] +1;		
			MPI_Recv(&Finx[p2[i][0]], n2[i], MPI_DOUBLE, i, 906, new_comm,&status);
		}
	}
}


void transfer_soln(cholmod_sparse *H, cholmod_dense *HTau,Int *HPinv, cholmod_dense *pi, cholmod_dense *Ydense, int *Cptr, int *rowPart, int *colPart, int *Mptr, MPI_Comm new_comm, cholmod_common *cc) {
	
	int numProcs, myId, i;
	MPI_Comm_size(new_comm, &numProcs);
	MPI_Comm_rank(new_comm, &myId);
		
	double *pix = (double *)pi->x ;
	int pc = pi->nrow;	
	
	//~ if(Mptr[numProcs-1] != 0)
	{		
				
		int nc = Cptr[myId]-Cptr[myId-1];
		int *Cindx=(int *) calloc(nc, sizeof(int));

		for (i=0; i<nc; i++) {
			Cindx[i]=i+Cptr[myId-1]+1;
		}
		double *Yx = (double *)Ydense->x;

		
		cholmod_dense *yt = (cholmod_dense *) cholmod_l_zeros(pc, 1, CHOLMOD_REAL,cc);
		cholmod_dense *C = (cholmod_dense *) cholmod_l_zeros(pc, 1, CHOLMOD_REAL,cc);	

		double *ytx = (double *)yt->x;
	
	
		int rm = pc-nc;
		for(int z =0;z< nc;z++)
		{
			ytx[rm + z]=Yx[Cindx[z]];
			
		}	
		C = SuiteSparseQR_qmult <double>(SPQR_QX, H, HTau, HPinv, yt, cc);
		printError((char *)"SuiteSparseQR_qmult TRANSFER", cc->status);		
		double *Xx = (double *)C->x ;
	
		/* updating x vector */		
		for (i =0; i< pc; i++) {
			Xx[i] = Xx[i] + pix[i];
		}
		
		/* send partial x vector to construct global solution on MASTER */
				
		//MPI_Send(&Xx[0], pc, MPI_DOUBLE, 0, 906, new_comm);
		//MPI_Request sendReqs = (MPI_Request *) malloc(sizeof(MPI_Request)*(numProcs));
		MPI_Request sendReqs;
		MPI_Isend(&Xx[0], pc, MPI_DOUBLE, 0, 906, new_comm,&sendReqs);
	}
	//~ else{	
		//~ /* send partial x vector to construct global solution on MASTER */
		//~ MPI_Send(&pix[0], pc, MPI_DOUBLE, 0, 906, new_comm);
	//~ }
	
}

double check_result(cholmod_sparse *GA, cholmod_dense *FinalResult,cholmod_dense *GlobalF, cholmod_common *cc) {
	double one [2] = { 1, 0 }, zero [2] = { 0, 0 };
	size_t i;
	cholmod_dense *GlobalRes = (cholmod_dense *) cholmod_l_allocate_dense(GA->nrow, 1, GA->nrow, CHOLMOD_REAL, cc);
	cholmod_l_sdmult(GA, FALSE, one, zero, FinalResult, GlobalRes, cc);
	double *Gx = (double *) GlobalRes->x;
	double *fx = (double *) GlobalF->x;
	for (i=0; i<GlobalRes->nrow; i++)
		Gx[i] = fx[i] -Gx[i];
	double norm1 = cholmod_l_norm_dense(GlobalRes, 2, cc);
	double norm2 = cholmod_l_norm_dense(GlobalF, 2, cc);
	return norm1/norm2;
	
	cholmod_l_free_dense(&GlobalRes, cc) ;

}

/**********************************************************************/
void readMatrixParts(char *finname, int *rowPart) {
	FILE *pf;
	int i, myId, numProcs, junk;
	MPI_Comm_size(MPI_COMM_WORLD, &numProcs);
	MPI_Comm_rank(MPI_COMM_WORLD, &myId);
	pf = fopen(finname, "r");
	if (!pf) {
		if (myId==0)
			printf("Can not open %s readMatrixParts \n", finname);
		MPI_Finalize();
		exit(1);
	}
	for (i = 0; i < numProcs+1; i++) {
		junk =fscanf(pf, "%d", &rowPart[i]);
	}
	fclose(pf);
	// printf("\n\t****\tMatrix parts readed  %d %d\t****\n",rowPart[0],rowPart[1]);
	return;
}

// R is n-by-n, upper triangular with zero-free diagonal
int Rsolve( Int n, cholmod_sparse *R, double *X, // X is n-by-nx, leading dimension n, overwritten with soln
		Int nx, cholmod_common *cc) {
	Int *Rp = (Int *) R->p;
	Int *Ri = (Int *) R->i;
	double *Rx = (double *) R->x ;

	double *tmp = (double *) calloc(n, sizeof(double));

	double rjj = Rx [0];
	tmp[0] = X [0] / rjj;

	for (Int j = 1; j <= n-1; j++) {
		double rjj = Rx [Rp [j+1]-1];
		if (rjj == (double) 0) {
			printf("Rsolve: R has an explicit zero on the diagonal\n") ;
			return (FALSE);
		}
		double sum=0;
		for (Int p = Rp [j]; p < Rp [j+1]; p++) {
			if (Ri[p]<j) {
				sum += Rx [p] * tmp [Ri[p]];
			}
			tmp [j] = X[j] -sum;
		}
		tmp[j] = tmp [j] / rjj;
	}

	for (int j = 0; j < n; j++) {
		X[j]= tmp[j];
	}
	free(tmp);
	return (TRUE);
}

void blknnz(cholmod_triplet *Tmp, cholmod_dense **gf, int *colPart,	int *rowPart, MPI_Comm comm, cholmod_common *cc) {

	cholmod_triplet *T = cholmod_l_copy_triplet(Tmp, cc);
	Int *Aj, *Ai;
	Int *Tj, *Ti;
	double *Ax, *Tx;
	Aj = (Int *)T->j;
	Ai = (Int *)T->i;
	Ax = (double *)T->x;
	Tj = (Int *)Tmp->j;
	Ti = (Int *)Tmp->i;
	Tx = (double *)Tmp->x;
	int myId,numProcs;
	size_t i;

	MPI_Comm_rank(comm, &myId);
	MPI_Comm_size(comm, &numProcs);

	int fsize = rowPart[myId+1]-rowPart[myId];
	int j=0;
	
	cholmod_dense *newf = (cholmod_dense *) cholmod_l_zeros(fsize, 1, CHOLMOD_REAL,cc);
	double *newfx = (double *) newf->x;
	double *gx = (double *)(*gf)->x;
	for(i=rowPart[myId];i<rowPart[myId+1];i++,j++)
	{
		newfx[j]=gx[i];
	}	
	
	int *colPartloc = (int *)calloc(sizeof(int), (numProcs+1)*2);
	int cnt=0, min=99999999, max=0;

	for (i=0; i<T->nnz; i++) {
		if (myId == 0) {
			if (Ai[i]<rowPart[myId+1]) {
				Ti[cnt] = Ai[i];
				Tj[cnt] = Aj[i];
				Tx[cnt] = Ax[i];
				//~ printf(" %ld %ld  %5.5f \n",Ti[cnt],Tj[cnt],Tx[cnt]); 
				if (Tj[cnt]>max)
					max=Tj[cnt];
				if (Tj[cnt]<min)
					min=Tj[cnt];
				cnt ++;
			}
		} else if (myId != numProcs-1) {
			if (Ai[i]<rowPart[myId+1] && Ai[i]>=rowPart[myId]) {
				Ti[cnt] = Ai[i];
				Tj[cnt] = Aj[i];// - (colPart[2*i]-1);
				Tx[cnt] = Ax[i];
				//~ printf(" %ld %ld  %5.5f \n",Ti[cnt],Tj[cnt],Tx[cnt]); 
				if (Tj[cnt]>max)
					max=Tj[cnt];
				if (Tj[cnt]<min)
					min=Tj[cnt];
				cnt ++;
			}
		} else {
			if (Ai[i]>=rowPart[myId]) {
				Ti[cnt] = Ai[i];
				Tj[cnt] = Aj[i];// - (Int)(colPart[2*myId]-1);
				Tx[cnt] = Ax[i];
				//~ printf("_ %ld %ld  %5.5f \n",Ti[cnt],(Int)(colPart[2*myId]-1),Tx[cnt]); 
				if (Tj[cnt]>max)
					max=Tj[cnt];
				if (Tj[cnt]<min)
					min=Tj[cnt];
				cnt ++;
			}
		}
	}
	colPartloc[myId*2]=min;
	colPartloc[(myId+1)*2-1]=max;

	MPI_Allreduce(colPartloc, colPart, numProcs*2, MPI_INT, MPI_SUM,comm);

	for (size_t i=0; i<T->nnz; i++) {
		Ti[i] -= (Int)(rowPart[myId]);
		Tj[i] -= (Int)(colPart[2*myId]);
	}

	Tmp->nrow=rowPart[myId+1]-rowPart[myId];
	Tmp->ncol=colPart[(myId+1)*2-1] - colPart[myId*2] +1;
	Tmp->nnz = cnt;
	Tmp->nzmax = cnt;

	cholmod_l_reallocate_triplet((size_t) cnt, Tmp, cc) ;
	printError((char *)"cholmod_l_reallocate_triplet > blknnz", cc->status);
	(*gf) = newf;
}


void readVector(char *fname, Int *A, int sz) {
	FILE *pf;
	int i, numProcs;
	MPI_Comm_size(MPI_COMM_WORLD, &numProcs);

	if (numProcs ==1) {
		for (i=0; i<sz; i++)
			A[i]=i;
		return;
	}

	pf = fopen(fname, "r");
	if (!pf) {
		int myId;
		MPI_Comm_rank(MPI_COMM_WORLD, &myId);
		if (myId==0)
			printf("Can not open %s readVector \n", fname);
		MPI_Finalize();
		exit(0);
		return;
	}

	int back=0;
	char *junk;
	char line[10000];
	junk =fgets(line, 10000, pf);
	while (line[0] == '#') {
		junk=fgets(line, 10000, pf);
	}
	back=sscanf(line, "%ld", &A[0]);
	for (i = 1; i < sz; i++) {
		back= fscanf(pf, "%ld", &A[i]);
	}
	fclose(pf);
	return;
}

void printusage() {
	printf("usage: balance [options] inputfilename\n");
	printf("\t-m matrix path\n");
	printf("\t-i block index file\n");
	printf("\t-r row order vector \n");
	printf("\t-c col order vector \n");
	printf("\t-n numthreads_SPQR for sparse QR opt\n");
	//printf("\t-q REMOVED! QR (1) or LU (0) for Reduced System\n");
	exit(1);
}

void parseinputs(int argc, char *argv[], char *mtxfile, char *rowPartfile,
		char *frow, char *fcol) {
	int c;
	while ((c = getopt(argc, argv, "m:i:r:c:n:o:")) != -1)
		switch (c) {
		case 'n':
			numthreads_SPQR = atoi(optarg);
			break;
		case 'm':
			sprintf(mtxfile, "%s", optarg);
			break;
		case 'i':
			sprintf(rowPartfile, "%s", optarg);
			break;
		case 'r':
			sprintf(frow, "%s", optarg);
			break;
		case 'c':
			sprintf(fcol, "%s", optarg);
			break;
		case 'o':
			ordering= atoi(optarg);
			break;
		default:
			printusage();
		}
	if (argc < 6)
		printusage();	
}


void printError(char *str, int cc) {
	if (cc != CHOLMOD_OK) {
		printf("\n ____ ERROR : %d _ %s  \n\n", cc, str);
		//~ MPI_Finalize();
		//~ exit(0);
	}
}
