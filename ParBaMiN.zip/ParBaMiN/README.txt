Author: Fahreddin Sukru Torun
email: fsukrutorun@gmail.com
date: August 2016
version: RD_v3

ParBaMiN : Parallel Balance Scheme Algorithm for Minimum Norm solution of parse Block Diagonal Column Overlapped Underdetermined Systems 

references: "Parallel Minimum Norm Solution of Sparse Block Diagonal Column Overlapped Underdetermined Systems", F. Sukru Torun, Murat Manguoglu, Cevdet Aykanat.

=======================================================================
SuiteSparse library should be installed on your system in order to compile this program.

This software is tested with
-SuiteSparse v4.5.3
-MKL version 11
-g++ 4.9.2
-Open MPI 1.6.5

========================================================================
For compilation:

modify Makefile according to your system.
Then run make command.

> make

=======================================================================
sample execution:

> mpirun -n 4 ./ParBaMiN -m lp_grow22.mtx -i lp_grow22.indices.4 -r ordered.order -c ordered.order -o 6 -n 1

usage: ./ParBaMiN [options] 
	-m matrix file
	-i indices for consecutive sub-matrices
	-r row order vector 
	-c col order vector 
	-o ordering for SuiteSparseQR (6: METIS ordering)
	-n numthreads_SPQR for number of TBB threads in SuiteSparseQR


