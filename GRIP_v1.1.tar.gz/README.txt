---------------------------------------------------------------------
                       GRIP Version 1.1
            Copyright (c) 2018-  by Fahreddin Sukru TORUN
---------------------------------------------------------------------
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <https://www.gnu.org/licenses/>.
 
 GRIP distribution is available free of charge for non-commercial, 
 research use by individuals, academic or research institutions 
 and corporations. Commercial use of GRIP software requires 
 commercial  license. Please direct commercial-use license 
 inquiries to fsukrutorun@gmail.com
---------------------------------------------------------------------


You can download latest distribution of GRIP
from  http://sukrutorun.com/GRIP.tar.gz

For questions, comments, suggestions, bugs please send e-mail to:

F. Sukru TORUN   fsukrutorun@gmail.com  ftorun@ybu.edu.tr

Usage: 
======================================================

There are 2 ways to use this library:
1. way: link libGRIP.a and include GRIP.h in your program while compiling
2. way: put GRIP.cpp into src/ folder and compile ABCD



Release Notes: 
======================================================
Changes from 1.0 to 1.1
-Improved integer casting method for metis.
-A small typo is fixed.





